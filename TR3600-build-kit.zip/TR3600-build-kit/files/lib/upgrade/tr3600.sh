# TR3600 V1 candidate dual-slot integration. Requires Cudy boot_param kernel patch.
# Loaded by OpenWrt's standard stage2; never run this file as an installer.

tr3600_stop() {
	echo "TR3600: $*" >&2
	return 1
}

tr3600_uint() {
	case "$1" in ''|*[!0-9]*) return 1;; esac
}

tr3600_param() {
	cat "/sys/module/boot_param/parameters/$1" 2>/dev/null
}

tr3600_volume_ebs() {
	local vol
	vol="$(nand_find_volume "$TR_UBI" "$1")"
	if [ -z "$vol" ]; then echo 0; return; fi
	cat "/sys/class/ubi/$vol/reserved_ebs"
}

tr3600_probe() {
	local current_slot envvol data_vol rootvol bootroot bootkernel root_param proof
	[ "$(board_name)" = 'cudy,tr3600-v1' ] || return 1
	[ "$(tr3600_param dual_boot)" = Y ] || {
		tr3600_stop 'missing dual-boot parameters'; return 1;
	}
	TR_BOOT="$(tr3600_param boot_image_slot)"
	TR_NEXT="$(tr3600_param upgrade_image_slot)"
	case "$TR_BOOT:$TR_NEXT" in
		0:1) TR_KERNEL=kernel2; TR_ROOT=rootfs2; bootroot=rootfs; bootkernel=kernel;;
		1:0) TR_KERNEL=kernel; TR_ROOT=rootfs; bootroot=rootfs2; bootkernel=kernel2;;
		*) tr3600_stop 'inconsistent slot numbers'; return 1;;
	esac
	[ "$(tr3600_param boot_rootfs_part)" = "$bootroot" ] &&
	[ "$(tr3600_param boot_kernel_part)" = "$bootkernel" ] &&
	[ "$(tr3600_param upgrade_kernel_part)" = "$TR_KERNEL" ] &&
	[ "$(tr3600_param upgrade_rootfs_part)" = "$TR_ROOT" ] &&
	[ "$(tr3600_param env_part)" = u-boot-env ] &&
	[ "$(tr3600_param rootfs_data_part)" = rootfs_data ] || {
		tr3600_stop 'inconsistent volume parameters'; return 1;
	}
	root_param="$(cat /sys/module/ubi/parameters/rootfs_volume 2>/dev/null)"
	[ "$root_param" = "$bootroot" ] || {
		tr3600_stop 'kernel rootfs selection disagrees with boot slot'; return 1;
	}
	TR_UBI="$(nand_find_ubi ubi)"
	[ -n "$TR_UBI" ] || { tr3600_stop 'UBI is not attached'; return 1; }
	rootvol="$(nand_find_volume "$TR_UBI" "$bootroot")"
	[ -n "$rootvol" ] || return 1
	# Confirm the mounted squashfs root is the volume selected by U-Boot.
	proof="$(cat /proc/sys/kernel/random/boot_id):$rootvol"
	if grep -q "^/dev/ubiblock${rootvol#ubi} /rom squashfs " /proc/mounts; then
		printf '%s\n' "$proof" > /tmp/tr3600-boot-proof || return 1
	else
		# stage2 has detached /rom. Require preflight proof from the same boot.
		[ "$(cat /tmp/tr3600-boot-proof 2>/dev/null)" = "$proof" ] || {
			tr3600_stop 'no matching mounted-root proof from preflight'; return 1;
		}
	fi
	envvol="$(nand_find_volume "$TR_UBI" u-boot-env)"
	[ -n "$envvol" ] || return 1
	TR_CFG=/tmp/tr3600-fw-env.config
	printf '/dev/%s 0 0x80000 0x80000 1\n' "$envvol" > "$TR_CFG" || return 1
	/usr/sbin/fw_printenv -c "$TR_CFG" > /dev/null || {
		tr3600_stop 'environment CRC/read failed'; return 1;
	}
	current_slot="$(/usr/sbin/fw_printenv -c "$TR_CFG" -n dual_boot.current_slot)" || return 1
	[ "$current_slot" = "$TR_BOOT" ] || {
		tr3600_stop 'environment and boot slot disagree'; return 1;
	}
	data_vol="$(nand_find_volume "$TR_UBI" rootfs_data)"
	[ -n "$data_vol" ] || return 1
	TR_LEB="$(cat "/sys/class/ubi/$TR_UBI/eraseblock_size")" || return 1
	TR_DATA_EBS="$(cat "/sys/class/ubi/$data_vol/reserved_ebs")" || return 1
	tr3600_uint "$TR_LEB" && tr3600_uint "$TR_DATA_EBS" || return 1
	[ "$TR_LEB" -gt 0 ] && [ "$TR_DATA_EBS" -gt 0 ] || return 1
	TR_DATA_BYTES=$((TR_LEB * TR_DATA_EBS))
}

tr3600_image_check() {
	local listing rootdir n
	listing="$(tar tf "$1")" || return 1
	rootdir="$(printf '%s\n' "$listing" | grep '^sysupgrade-[^/]*/$')"
	[ "$rootdir" = 'sysupgrade-cudy_tr3600-v1/' ] || {
		tr3600_stop 'unexpected image directory'; return 1;
	}
	TR_DIR="${rootdir%/}"
	for n in CONTROL kernel root; do
		[ "$(printf '%s\n' "$listing" | grep -xc "$TR_DIR/$n")" = 1 ] || return 1
	done
	nand_verify_tar_file "$1" cat || return 1
	TR_KSIZE="$(tar xOf "$1" "$TR_DIR/kernel" | wc -c)"
	TR_RSIZE="$(tar xOf "$1" "$TR_DIR/root" | wc -c)"
	# wc can include whitespace; arithmetic produces canonical numbers.
	TR_KSIZE=$((TR_KSIZE)); TR_RSIZE=$((TR_RSIZE))
	[ "$TR_KSIZE" -gt 0 ] && [ "$TR_KSIZE" -le 6291456 ] &&
	[ "$TR_RSIZE" -gt 0 ] && [ "$TR_RSIZE" -le 33554432 ] || {
		tr3600_stop 'image exceeds reviewed dual-slot size budget'; return 1;
	}
	[ "$(identify_tar "$1" cat "$TR_DIR/root")" = squashfs ] || return 1
}

tr3600_capacity_check() {
	local free kernel_old root_old need available
	free="$(cat "/sys/class/ubi/$TR_UBI/avail_eraseblocks")" || return 1
	kernel_old="$(tr3600_volume_ebs "$TR_KERNEL")" || return 1
	root_old="$(tr3600_volume_ebs "$TR_ROOT")" || return 1
	tr3600_uint "$free" && tr3600_uint "$kernel_old" && tr3600_uint "$root_old" || return 1
	available=$((free + kernel_old + root_old + TR_DATA_EBS))
	need=$(((TR_KSIZE + TR_LEB - 1) / TR_LEB + (TR_RSIZE + TR_LEB - 1) / TR_LEB + TR_DATA_EBS + 8))
	[ "$available" -ge "$need" ] || {
		tr3600_stop "insufficient space: $available LEBs available, $need required"; return 1;
	}
}

tr3600_check() {
	tr3600_probe && tr3600_image_check "$1" && tr3600_capacity_check
}

tr3600_readback_hash() {
	local vol="$1" size="$2"
	# Expected hash catches short reads and I/O errors even without shell pipefail.
	dd if="/dev/$vol" bs=4096 count=$(((size + 4095) / 4096)) 2>/dev/null |
		head -c "$size" | sha256sum | cut -d ' ' -f 1
}

tr3600_do_upgrade() {
	local kh rh kv rv commit_file
	tr3600_check "$1" || { nand_do_upgrade_failed; return 1; }
	kh="$(tar xOf "$1" "$TR_DIR/kernel" | sha256sum | cut -d ' ' -f 1)"
	rh="$(tar xOf "$1" "$TR_DIR/root" | sha256sum | cut -d ' ' -f 1)"
	CI_UBIPART=ubi; CI_KERNPART="$TR_KERNEL"; CI_ROOTPART="$TR_ROOT"
	# Standard NAND upgrade recreates the shared data volume. Preserve its
	# allocation, rather than allowing a stale rootfs_data_max to shrink it.
	fw_printenv() {
		if [ "$1" = -n ] && [ "$2" = rootfs_data_max ]; then
			echo "$TR_DATA_BYTES"
		else
			/usr/sbin/fw_printenv -c "$TR_CFG" "$@"
		fi
	}
	nand_do_flash_file "$1" || { nand_do_upgrade_failed; return 1; }
	[ "$(tr3600_volume_ebs rootfs_data)" = "$TR_DATA_EBS" ] || {
		tr3600_stop 'shared data allocation changed; boot slot not changed'
		nand_do_upgrade_failed; return 1
	}
	kv="$(nand_find_volume "$TR_UBI" "$TR_KERNEL")"
	rv="$(nand_find_volume "$TR_UBI" "$TR_ROOT")"
	[ -n "$kv" ] && [ -n "$rv" ] &&
	[ "$(tr3600_readback_hash "$kv" "$TR_KSIZE")" = "$kh" ] &&
	[ "$(tr3600_readback_hash "$rv" "$TR_RSIZE")" = "$rh" ] || {
		tr3600_stop 'flash readback mismatch; boot slot not changed'
		nand_do_upgrade_failed; return 1
	}
	nand_do_restore_config && sync || { nand_do_upgrade_failed; return 1; }
	# fw_setenv -s uses SPACE-separated name/value pairs; commit both together.
	commit_file=/tmp/tr3600-slot-commit
	printf 'dual_boot.slot_%s_invalid 0\ndual_boot.current_slot %s\n' "$TR_NEXT" "$TR_NEXT" > "$commit_file" || return 1
	/usr/sbin/fw_setenv -c "$TR_CFG" -s "$commit_file" || { nand_do_upgrade_failed; return 1; }
	[ "$(/usr/sbin/fw_printenv -c "$TR_CFG" -n dual_boot.current_slot)" = "$TR_NEXT" ] &&
	[ "$(/usr/sbin/fw_printenv -c "$TR_CFG" -n "dual_boot.slot_${TR_NEXT}_invalid")" = 0 ] || {
		tr3600_stop 'boot environment readback failed'; nand_do_upgrade_failed; return 1;
	}
	sync
	echo "TR3600: verified $TR_KERNEL/$TR_ROOT; boot slot committed to $TR_NEXT"
	umount -a
	reboot -f
}
