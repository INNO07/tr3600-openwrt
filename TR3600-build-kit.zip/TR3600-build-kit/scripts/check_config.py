#!/usr/bin/env python3
"""Reject silently dropped required selections after make defconfig."""
import pathlib
import sys

seed = pathlib.Path(sys.argv[1]).read_text().splitlines()
resolved = set(pathlib.Path(sys.argv[2]).read_text().splitlines())
required = [s for s in seed if s.startswith('CONFIG_') and s.endswith('=y')]
missing = [s for s in required if s not in resolved]
if 'CONFIG_PACKAGE_dnsmasq=y' in resolved:
    missing.append('dnsmasq must be replaced with dnsmasq-full')
if missing:
    raise SystemExit('CONFIG_CHECK_FAILED:\n' + '\n'.join(missing))
print(f'CONFIG_OK: {len(required)} required selections retained')
