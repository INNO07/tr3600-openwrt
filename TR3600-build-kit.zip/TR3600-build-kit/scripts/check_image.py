#!/usr/bin/env python3
"""Inspect final sysupgrade payload and fwtool metadata; never flashes."""
import hashlib
import json
import pathlib
import struct
import sys
import tarfile

image = pathlib.Path(sys.argv[1])
out = pathlib.Path(sys.argv[2])
blob = image.read_bytes()
# Read metadata with the OpenWrt-built fwtool separately in the workflow.
meta = json.loads(out.read_text())
assert 'cudy,tr3600-v1' in meta['supported_devices'], meta
with tarfile.open(image) as tar:
    prefix = 'sysupgrade-cudy_tr3600-v1/'
    for component, limit in [('kernel', 6*1024*1024), ('root', 32*1024*1024)]:
        member = tar.getmember(prefix+component)
        assert member.isfile() and 0 < member.size <= limit, (component, member.size, limit)
        content = tar.extractfile(member).read()
        if component == 'root':
            assert content[:4] == b'hsqs', 'root must be squashfs'
        print(component, member.size, hashlib.sha256(content).hexdigest())
print('IMAGE_OK', image.name, len(blob), hashlib.sha256(blob).hexdigest())
