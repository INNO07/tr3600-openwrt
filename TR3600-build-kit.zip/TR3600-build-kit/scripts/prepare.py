#!/usr/bin/env python3
"""Apply reviewed integration to an EXACT upstream OpenWrt checkout."""
import pathlib
import shutil
import subprocess
import sys

kit = pathlib.Path(__file__).resolve().parents[1]
tree = pathlib.Path(sys.argv[1]).resolve()
expected = 'f0a60eee2fe051741c643ea6118718aae1ef17fb'
actual = subprocess.check_output(['git', '-C', str(tree), 'rev-parse', 'HEAD'], text=True).strip()
if actual != expected:
    raise SystemExit(f'Unexpected base {actual}, expected {expected}')
if subprocess.check_output(['git', '-C', str(tree), 'status', '--porcelain'], text=True):
    raise SystemExit('Prepare requires a clean build tree')
for name in ['100-tr3600-device.patch', '110-tr3600-hardware.patch']:
    subprocess.run(['git', '-C', str(tree), 'apply', '--check', str(kit/'patches'/name)], check=True)
    subprocess.run(['git', '-C', str(tree), 'apply', str(kit/'patches'/name)], check=True)
shutil.copy2(kit/'patches/999-ubi-add-configurable-rootdev.patch',
             tree/'target/linux/mediatek/patches-6.12/999-ubi-add-configurable-rootdev.patch')
path = tree/'target/linux/mediatek/filogic/base-files/lib/upgrade/platform.sh'
text = path.read_text()
text = text.replace("RAMFS_COPY_BIN='fitblk fit_check_sign'",
                    "RAMFS_COPY_BIN='fitblk fit_check_sign sha256sum head'", 1)
needle = 'platform_do_upgrade() {\n\tlocal board=$(board_name)\n'
assert needle in text, 'platform_do_upgrade entry changed'
text = text.replace(needle, needle + '''
\tif [ "$board" = 'cudy,tr3600-v1' ]; then
\t\ttr3600_do_upgrade "$1"
\t\treturn $?
\tfi
''', 1)
needle = 'platform_check_image() {\n\tlocal board=$(board_name)\n'
assert needle in text, 'platform_check_image entry changed'
text = text.replace(needle, needle + '''
\tif [ "$board" = 'cudy,tr3600-v1' ]; then
\t\t[ "$#" = 1 ] || return 1
\t\ttr3600_check "$1"
\t\treturn $?
\tfi
''', 1)
path.write_text(text)
shutil.copytree(kit/'files', tree/'files', dirs_exist_ok=True)
(tree/'files/etc/tr3600-candidate-id').write_text(
    'TR3600 V1 candidate / OpenWrt 25.12.5\n'
    'base=f0a60eee2fe051741c643ea6118718aae1ef17fb\n'
    'openclash=e553e82e01c697aefbe1555261a503f425e00ccd\n'
    'Hardware acceptance tests pending\n')
for path in (tree/'files/etc/uci-defaults').glob('*'):
    path.chmod(0o755)
for path in (tree/'files/usr/sbin').glob('*'):
    path.chmod(0o755)
shutil.copy2(kit/'config.seed', tree/'.config')
print('PREPARE_OK: fixed base, device, hardware and dual-slot integration applied')
