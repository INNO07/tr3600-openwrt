#!/usr/bin/env bash
set -euo pipefail
kit=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
tree=${BUILD_TREE:-"$PWD/openwrt-build"}
test "$(uname -s)" = Linux || { echo 'Requires a Linux build host'; exit 1; }
test ! -e "$tree" || { echo 'Use a fresh BUILD_TREE'; exit 1; }
git init "$tree"
git -C "$tree" remote add origin https://github.com/openwrt/openwrt.git
git -C "$tree" fetch --depth=1 origin f0a60eee2fe051741c643ea6118718aae1ef17fb
git -C "$tree" checkout --detach FETCH_HEAD
python3 "$kit/scripts/prepare.py" "$tree"
cd "$tree"
# Release feeds.conf.default contains exact feed commits, not floating branches.
./scripts/feeds update -a
./scripts/feeds install -a
git init package/openclash-source
git -C package/openclash-source remote add origin https://github.com/vernesong/OpenClash.git
git -C package/openclash-source fetch --depth=1 origin e553e82e01c697aefbe1555261a503f425e00ccd
git -C package/openclash-source checkout --detach FETCH_HEAD
make defconfig
python3 "$kit/scripts/check_config.py" "$kit/config.seed" .config
mkdir -p "$kit/artifacts"
cp .config "$kit/artifacts/config.full"
cp feeds.conf.default "$kit/artifacts/feeds.lock"
./scripts/diffconfig.sh > "$kit/artifacts/config.diff"
git diff > "$kit/artifacts/source-changes.diff"
git rev-parse HEAD > "$kit/artifacts/openwrt.commit"
git -C package/openclash-source rev-parse HEAD > "$kit/artifacts/openclash.commit"
make -j2 download
make -j2 V=s
image=bin/targets/mediatek/filogic/openwrt-25.12.5-mediatek-filogic-cudy_tr3600-v1-squashfs-sysupgrade.bin
test -f "$image"
staging_dir/host/bin/fwtool -i "$kit/artifacts/image-metadata.json" "$image"
python3 "$kit/scripts/check_image.py" "$image" "$kit/artifacts/image-metadata.json" | tee "$kit/artifacts/image-check.txt"
cp "$image" "$kit/artifacts/"
cp bin/targets/mediatek/filogic/*.manifest "$kit/artifacts/"
cp bin/targets/mediatek/filogic/profiles.json "$kit/artifacts/"
cp "$kit/scripts/install-mihomo.sh" "$kit/artifacts/"
cp "$kit/README.md" "$kit/artifacts/"
# Ship Mihomo separately to keep both firmware slots within the size budget.
curl --fail --location --retry 3 \
  https://github.com/MetaCubeX/mihomo/releases/download/v1.19.32/mihomo-linux-arm64-v1.19.32.gz \
  -o "$kit/artifacts/mihomo-linux-arm64-v1.19.32.gz"
echo '9dd862e28b46ff7d775f169cceebc28deccaa0a9e804237d421cd2571e0caba0  mihomo-linux-arm64-v1.19.32.gz' |
  (cd "$kit/artifacts" && sha256sum -c -)
printf '%s\n' 'CANDIDATE: build/metadata checks only; TR3600 hardware and plugin coexistence tests pending.' > "$kit/artifacts/STATUS.txt"
(cd "$kit/artifacts" && sha256sum *.bin *.gz > SHA256SUMS)
