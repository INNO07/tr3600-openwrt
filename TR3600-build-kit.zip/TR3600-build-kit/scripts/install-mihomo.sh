#!/bin/sh
# Run only on the new candidate OpenWrt after copying the verified .gz to /tmp.
set -eu
[ "$(cat /tmp/sysinfo/board_name)" = cudy,tr3600-v1 ]
[ "$(uname -m)" = aarch64 ]
src=${1:-/tmp/mihomo-linux-arm64-v1.19.32.gz}
[ "$(sha256sum "$src" | cut -d ' ' -f 1)" = 9dd862e28b46ff7d775f169cceebc28deccaa0a9e804237d421cd2571e0caba0 ]
free_kb=$(df -Pk /overlay | awk 'NR==2 {print $4}')
raw_bytes=$(gzip -dc "$src" | wc -c)
[ "$free_kb" -ge $(((raw_bytes + 1023) / 1024 + 8192)) ] || {
    echo 'Not enough overlay space to safely install the core'; exit 1;
}
mkdir -p /etc/openclash/core
gzip -dc "$src" > /etc/openclash/core/clash_meta.new
[ "$(sha256sum /etc/openclash/core/clash_meta.new | cut -d ' ' -f 1)" = c80df2ca5159567804da883401e0118908fc1155e05df2baf3dbd4d3ecfc3754 ]
chmod 755 /etc/openclash/core/clash_meta.new
/etc/openclash/core/clash_meta.new -v
/etc/init.d/openclash stop
mv /etc/openclash/core/clash_meta.new /etc/openclash/core/clash_meta
uci set openclash.config.core_type=Meta
uci set openclash.config.core_version=linux-arm64
uci commit openclash
echo 'Mihomo installed; import a subscription/config before enabling OpenClash.'
