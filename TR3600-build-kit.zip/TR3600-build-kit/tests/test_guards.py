"""Control-flow tests using files and mocks, never router/flash devices."""
import io
import os
import pathlib
import subprocess
import tarfile
import tempfile
import unittest

KIT = pathlib.Path(__file__).resolve().parents[1]


class Guards(unittest.TestCase):
    def run_case(self, slot=0, change=None, fail='', ram=False):
        with tempfile.TemporaryDirectory() as d:
            root = pathlib.Path(d)
            def put(p, value):
                p = root/p
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(str(value))
            suffix = '' if slot == 0 else '2'
            nxt = 1-slot
            target = '2' if slot == 0 else ''
            params = dict(dual_boot='Y', boot_image_slot=slot, upgrade_image_slot=nxt,
                          boot_kernel_part='kernel'+suffix, boot_rootfs_part='rootfs'+suffix,
                          upgrade_kernel_part='kernel'+target, upgrade_rootfs_part='rootfs'+target,
                          env_part='u-boot-env', rootfs_data_part='rootfs_data')
            if change:
                params.update(change)
            for k, v in params.items():
                put('sys/module/boot_param/parameters/'+k, str(v)+'\n')
            put('sys/module/ubi/parameters/rootfs_volume', 'rootfs'+suffix+'\n')
            put('sys/class/ubi/ubi0/eraseblock_size', 126976)
            put('sys/class/ubi/ubi0/avail_eraseblocks', 0 if fail == 'space' else 200)
            put('proc/sys/kernel/random/boot_id', 'test-boot-123\n')
            ids = {'u-boot-env': 0, 'kernel': 1, 'kernel2': 2, 'rootfs': 3, 'rootfs2': 5, 'rootfs_data': 4}
            for name, idx in ids.items():
                ebs = 1157 if name == 'rootfs_data' else (0 if fail == 'space' else 24)
                put(f'sys/class/ubi/ubi0_{idx}/reserved_ebs', ebs)
                put(f'dev/ubi0_{idx}', 'old-'+name)
            mounted = f'/dev/ubiblock0_{ids["rootfs"+suffix]} /rom squashfs ro 0 0\n'
            put('proc/mounts', mounted)
            put('slot', slot)
            image = root/'image.tar'
            with tarfile.open(image, 'w') as tar:
                prefix = 'sysupgrade-cudy_tr3600-v1/'
                info = tarfile.TarInfo(prefix); info.type = tarfile.DIRTYPE; tar.addfile(info)
                for name, data in [('CONTROL', b'BOARD=test\n'), ('kernel', b'test-kernel'), ('root', b'hsqs-test-root')]:
                    info = tarfile.TarInfo(prefix+name); info.size = len(data)
                    tar.addfile(info, io.BytesIO(data))
            log = root/'log'
            put('fw_printenv', '''#!/bin/sh
if [ "$FAIL" = env ]; then exit 1; fi
case "$*" in *dual_boot.current_slot*) cat "$TEST_ROOT/slot";; *invalid*) echo 0;; *) echo valid;; esac
''')
            put('fw_setenv', '''#!/bin/sh
echo commit >> "$TEST_ROOT/log"
if [ "$FAIL" = commit ]; then exit 1; fi
awk '$1=="dual_boot.current_slot" {print $2}' "$4" > "$TEST_ROOT/slot"
''')
            for name in ('fw_printenv', 'fw_setenv'):
                (root/name).chmod(0o755)
            source = (KIT/'files/lib/upgrade/tr3600.sh').read_text()
            # Redirect all I/O to a temporary directory, including dummy device files.
            source = source.replace('/usr/sbin/fw_printenv', str(root/'fw_printenv'))
            source = source.replace('/usr/sbin/fw_setenv', str(root/'fw_setenv'))
            for p in ['/sys/', '/proc/', '/dev/', '/tmp/']:
                source = source.replace(p, str(root)+p)
            # The mocked /proc/mounts must use the matching redirected device prefix.
            put('proc/mounts', mounted.replace('/dev/', str(root)+'/dev/'))
            (root/'tmp').mkdir(exist_ok=True)
            put('subject.sh', source)
            wrappers = '''
board_name() { echo cudy,tr3600-v1; }
nand_find_ubi() { echo ubi0; }
nand_find_volume() {
 case "$2" in
 u-boot-env) echo ubi0_0;; kernel) echo ubi0_1;; kernel2) echo ubi0_2;;
 rootfs) echo ubi0_3;; rootfs_data) echo ubi0_4;; rootfs2) echo ubi0_5;; esac
}
nand_verify_tar_file() { tar tf "$1" >/dev/null; }
identify_tar() { echo squashfs; }
nand_do_flash_file() {
 echo flash >> "$TEST_ROOT/log"
 test "$FAIL" != flash || return 1
 echo "allocation=$(fw_printenv -n rootfs_data_max)" >> "$TEST_ROOT/log"
 local k=$(nand_find_volume ubi0 "$CI_KERNPART") r=$(nand_find_volume ubi0 "$CI_ROOTPART")
 tar xOf "$1" "$TR_DIR/kernel" > "$TEST_ROOT/dev/$k"
 tar xOf "$1" "$TR_DIR/root" > "$TEST_ROOT/dev/$r"
 if [ "$FAIL" = readback ]; then echo corrupt > "$TEST_ROOT/dev/$r"; fi
 if [ "$FAIL" = allocation ]; then echo 1156 > "$TEST_ROOT/sys/class/ubi/ubi0_4/reserved_ebs"; fi
}
nand_do_restore_config() { echo restore >> "$TEST_ROOT/log"; test "$FAIL" != restore; }
nand_do_upgrade_failed() { echo failed >> "$TEST_ROOT/log"; return 1; }
sync() { :; }
umount() { echo umount >> "$TEST_ROOT/log"; }
reboot() { echo reboot >> "$TEST_ROOT/log"; }
'''
            ram_stage = '''
tr3600_check "$TEST_ROOT/image.tar" || exit 1
: > "$TEST_ROOT/proc/mounts"
''' if ram else ''
            script = wrappers + '\n. "$TEST_ROOT/subject.sh"\n' + ram_stage + '\ntr3600_do_upgrade "$TEST_ROOT/image.tar"\n'
            env = dict(os.environ, TEST_ROOT=str(root), FAIL=fail)
            result = subprocess.run(['sh'], input=script, text=True, env=env, capture_output=True)
            lines = log.read_text().splitlines() if log.exists() else []
            return result, lines, (root/'slot').read_text().strip()

    def test_success_both_directions(self):
        for slot in (0, 1):
            with self.subTest(slot=slot):
                result, log, current = self.run_case(slot=slot)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(current, str(1-slot))
                self.assertEqual(log, ['flash', 'allocation=146911232', 'restore', 'commit', 'umount', 'reboot'])

    def test_ram_handoff_uses_same_boot_proof(self):
        result, log, current = self.run_case(ram=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(current, '1')

    def test_invalid_slot_does_not_write(self):
        result, log, current = self.run_case(change={'upgrade_image_slot': 0})
        self.assertNotEqual(result.returncode, 0)
        self.assertNotIn('flash', log)
        self.assertNotIn('commit', log)

    def test_invalid_volume_does_not_write(self):
        result, log, current = self.run_case(change={'upgrade_rootfs_part': 'rootfs'})
        self.assertNotEqual(result.returncode, 0)
        self.assertNotIn('flash', log)

    def test_preflight_failures_do_not_write(self):
        for failure in ('env', 'space'):
            with self.subTest(failure=failure):
                result, log, current = self.run_case(fail=failure)
                self.assertNotEqual(result.returncode, 0)
                self.assertNotIn('flash', log)
                self.assertEqual(current, '0')

    def test_post_write_failures_do_not_commit(self):
        for failure in ('flash', 'readback', 'allocation', 'restore'):
            with self.subTest(failure=failure):
                result, log, current = self.run_case(fail=failure)
                self.assertNotEqual(result.returncode, 0)
                self.assertNotIn('commit', log)
                self.assertNotIn('reboot', log)
                self.assertEqual(current, '0')

    def test_env_commit_failure_reports_failure(self):
        result, log, current = self.run_case(fail='commit')
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('commit', log)
        self.assertNotIn('reboot', log)
        self.assertEqual(current, '0')


if __name__ == '__main__':
    unittest.main()
