"""Run firstboot settings against a mock UCI; never touches real devices."""
import os
import pathlib
import subprocess
import tempfile
import unittest

KIT=pathlib.Path(__file__).resolve().parents[1]
EXPECTED_IP=(KIT/'files/etc/tr3600-default-lan').read_text().strip()
class Defaults(unittest.TestCase):
    def run_defaults(self, board):
        with tempfile.TemporaryDirectory() as td:
            log=pathlib.Path(td)/'uci.log'
            wrapper='''
cat() { if [ "$1" = /tmp/sysinfo/board_name ]; then printf '%s\\n' "$TEST_BOARD"; else command cat "$@"; fi; }
uci() {
 printf '%s\\n' "$*" >> "$UCI_LOG"
 case "$*" in '-q show wireless') printf '%s\\n' 'wireless.radio0=wifi-device' 'wireless.radio1=wifi-device';; esac
 return 0
}
. "$TEST_SUBJECT"
'''
            env=dict(os.environ,TEST_BOARD=board,UCI_LOG=str(log),TEST_SUBJECT=str(KIT/'files/etc/uci-defaults/99-tr3600-defaults'))
            r=subprocess.run(['sh'],input=wrapper,text=True,env=env,capture_output=True)
            self.assertEqual(r.returncode,0,r.stderr)
            return log.read_text().splitlines() if log.exists() else []
    def test_lan10_without_changing_ports_or_setting_credentials(self):
        calls=self.run_defaults('cudy,tr3600-v1')
        self.assertIn('-q set network.lan.ipaddr='+EXPECTED_IP,calls)
        self.assertIn('-q set network.lan.netmask=255.255.255.0',calls)
        self.assertIn('-q commit network',calls)
        self.assertIn('-q set openclash.config.enable=0',calls)
        self.assertIn('-q set wireless.radio0.country=CN',calls)
        self.assertIn('-q set wireless.radio1.country=CN',calls)
        for c in calls:
            self.assertNotIn('network.wan.device=',c)
            self.assertNotIn('network.lan.device=',c)
            self.assertNotIn('.password=',c)
            self.assertNotIn('.key=',c)
            self.assertNotIn('.token=',c)
    def test_other_board_is_untouched(self):
        self.assertEqual(self.run_defaults('other,board'),[])
    def test_configuration_check_enforces_address_string(self):
        with tempfile.TemporaryDirectory() as td:
            seed=pathlib.Path(td)/'seed'; resolved=pathlib.Path(td)/'config'
            seed.write_text('CONFIG_PACKAGE_cloudflared=y\nCONFIG_TARGET_PREINIT_IP="192.168.10.1"\n')
            resolved.write_text('CONFIG_PACKAGE_cloudflared=y\nCONFIG_TARGET_PREINIT_IP="192.168.1.1"\n')
            r=subprocess.run(['python3',str(KIT/'scripts/check_config.py'),str(seed),str(resolved)],capture_output=True,text=True)
            self.assertNotEqual(r.returncode,0)
            self.assertIn('CONFIG_TARGET_PREINIT_IP',r.stderr)
            resolved.write_text(seed.read_text())
            r=subprocess.run(['python3',str(KIT/'scripts/check_config.py'),str(seed),str(resolved)],capture_output=True,text=True)
            self.assertEqual(r.returncode,0,r.stderr)
if __name__=='__main__':unittest.main()
