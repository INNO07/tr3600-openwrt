#!/usr/bin/env python3
"""Select one of two explicit, validated build variants; no router access."""
import pathlib
import re
import sys

kit=pathlib.Path(__file__).resolve().parents[1]
ip=sys.argv[1] if len(sys.argv)==2 else ''
if ip not in ('192.168.1.1','192.168.10.1'):
    raise SystemExit('Only 192.168.1.1 or 192.168.10.1 is supported')
seed=kit/'config.seed'
firstboot=kit/'files/etc/uci-defaults/99-tr3600-defaults'
# Validate both expected anchors before changing any files.
text=seed.read_text()
script=firstboot.read_text()
assert len(re.findall(r'^CONFIG_TARGET_PREINIT_IP="[^"\n]+"$',text,re.M))==1
assert len(re.findall(r'^uci -q set network\.lan\.ipaddr=\d+\.\d+\.\d+\.\d+$',script,re.M))==1
text=re.sub(r'^CONFIG_TARGET_PREINIT_IP="[^"\n]+"$',f'CONFIG_TARGET_PREINIT_IP="{ip}"',text,flags=re.M)
script=re.sub(r'^uci -q set network\.lan\.ipaddr=\d+\.\d+\.\d+\.\d+$',f'uci -q set network.lan.ipaddr={ip}',script,flags=re.M)
seed.write_text(text)
firstboot.write_text(script)
(kit/'files/etc/tr3600-default-lan').write_text(ip+'\n')
print('VARIANT_OK: LAN and failsafe default IP =',ip)
