#!/usr/bin/env python3
"""Check actual built SquashFS content, not just the requested package seed."""
import json
import pathlib
import subprocess
import sys
import tarfile
import tempfile

image=pathlib.Path(sys.argv[1]).resolve()
unsquashfs=pathlib.Path(sys.argv[2]).resolve()
assert unsquashfs.is_file(), ('missing SquashFS inspection tool',str(unsquashfs))
expected_ip=sys.argv[3]
assert expected_ip in ('192.168.1.1','192.168.10.1')
with tempfile.TemporaryDirectory(prefix='tr3600-rootfs-check-') as d:
    work=pathlib.Path(d)
    with tarfile.open(image) as tar:
        member=tar.getmember('sysupgrade-cudy_tr3600-v1/root')
        assert member.isfile() and member.size <= 32*1024*1024
        (work/'root.squashfs').write_bytes(tar.extractfile(member).read())
    # Read file contents directly. Full extraction would try to create /dev/console
    # on the CI host and fail without root; no device nodes are needed for audit.
    def read_bytes(name):
        data=subprocess.check_output([str(unsquashfs),'-cat',str(work/'root.squashfs'),name])
        assert data, ('empty built-in component',name)
        return data
    def read_text(name):
        return read_bytes(name).decode('utf-8')
    required=[
        'usr/bin/cloudflared',
        'etc/init.d/cloudflared',
        'usr/share/luci/menu.d/luci-app-cloudflared.json',
        'usr/share/rpcd/acl.d/luci-app-cloudflared.json',
        'usr/lib/lua/luci/i18n/cloudflared.zh-cn.lmo',
        'etc/init.d/openclash',
        'usr/lib/lua/luci/controller/openclash.lua',
        'etc/uci-defaults/99-tr3600-defaults',
        'lib/upgrade/tr3600.sh',
        'lib/preinit/00_preinit.conf',
        'etc/board.d/99-lan-ip',
    ]
    for name in required:
        read_bytes(name)
    import re
    preinit=read_text('lib/preinit/00_preinit.conf')
    assert re.search(r'^pi_ip="?'+re.escape(expected_ip)+r'"?$',preinit,re.M), 'Actual failsafe IP mismatch'
    broadcast=expected_ip.rsplit('.',1)[0]+'.255'
    assert re.search(r'^pi_broadcast="?'+re.escape(broadcast)+r'"?$',preinit,re.M), 'Actual failsafe broadcast mismatch'
    assert expected_ip in read_text('etc/board.d/99-lan-ip'), 'Actual board LAN default mismatch'
    defaults=read_text('etc/uci-defaults/99-tr3600-defaults')
    assert 'uci -q set network.lan.ipaddr='+expected_ip in defaults
    assert read_text('etc/tr3600-default-lan').strip()==expected_ip
    assert 'lan='+expected_ip in read_text('etc/tr3600-candidate-id')
    assert 'uci -q commit network' in defaults
    assert 'uci -q set openclash.config.enable=0' in defaults
    menu=json.loads(read_text('usr/share/luci/menu.d/luci-app-cloudflared.json'))
    views=[]
    for entry in menu.values():
        action=entry.get('action',{})
        if action.get('type')=='view':
            view='www/luci-static/resources/view/'+action['path']+'.js'
            read_bytes(view)
            views.append(view)
    assert views, 'Cloudflared menu does not include a view'
    print('ROOTFS_OK: actual image contains cloudflared binary/init/menu/ACL/Chinese translation and views, OpenClash interface, selected LAN firstboot settings and upgrade guard.')
    print('Cloudflared menu paths:',', '.join(menu))
    print('Mihomo core intentionally supplied as a separately verified companion artifact.')
