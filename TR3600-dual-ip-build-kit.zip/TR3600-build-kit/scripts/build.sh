#!/usr/bin/env bash
set -euo pipefail
kit=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
tree=${BUILD_TREE:-"$PWD/openwrt-build"}
test "$(uname -s)" = Linux || { echo 'Requires a Linux build host'; exit 1; }
test ! -e "$tree" || { echo 'Use a fresh BUILD_TREE'; exit 1; }
lan_ip=$(cat "$kit/files/etc/tr3600-default-lan")
case "$lan_ip" in 192.168.1.1|192.168.10.1) ;; *) echo 'Invalid LAN variant'; exit 1;; esac

unsquashfs=$(command -v unsquashfs) || { echo "Missing squashfs-tools: install before building"; exit 1; }
"$unsquashfs" -version > /dev/null
mksquashfs=$(command -v mksquashfs) || { echo "Missing squashfs-tools compressor for smoke test"; exit 1; }
probe=$(mktemp -d)
mkdir "$probe/input"
printf "%s\n" ROOTFS_TOOL_OK > "$probe/input/probe"
"$mksquashfs" "$probe/input" "$probe/probe.sqfs" -noappend -comp xz -processors 1 -no-progress -quiet
"$unsquashfs" -cat "$probe/probe.sqfs" probe > "$probe/readback"
cmp "$probe/input/probe" "$probe/readback"
rm -rf "$probe"
echo SQUASHFS_TOOL_SMOKE_OK

git init "$tree"
git -C "$tree" remote add origin https://github.com/openwrt/openwrt.git
git -C "$tree" fetch --depth=1 origin f0a60eee2fe051741c643ea6118718aae1ef17fb
git -C "$tree" checkout --detach FETCH_HEAD
python3 "$kit/scripts/prepare.py" "$tree"
cd "$tree"
# Release feeds.conf.default contains exact feed commits, not floating branches.
./scripts/feeds update -a
./scripts/feeds install -a
git init package/openclash-source
git -C package/openclash-source remote add origin https://github.com/vernesong/OpenClash.git
git -C package/openclash-source fetch --depth=1 origin e553e82e01c697aefbe1555261a503f425e00ccd
git -C package/openclash-source checkout --detach FETCH_HEAD
# OpenClash invokes po2lmo in Build/Prepare. Declare its host-tool dependency
# explicitly so parallel builds cannot reach that step before it is installed.
python3 - <<'PYCODE'
from pathlib import Path
p = Path('package/openclash-source/luci-app-openclash/Makefile')
text = p.read_text()
needle = 'PKG_BUILD_DIR:=$(BUILD_DIR)/$(PKG_NAME)\n'
assert text.count(needle) == 1 and 'PKG_BUILD_DEPENDS' not in text
p.write_text(text.replace(needle, needle + 'PKG_BUILD_DEPENDS:=luci-base/host\n', 1))
PYCODE
# Feed initialization may run Kconfig before external packages exist, dropping
# their selections. Reapply the seed AFTER all package definitions are installed.
cp "$kit/config.seed" .config
make defconfig
mkdir -p "$kit/artifacts"
cp .config "$kit/artifacts/config.full"
cp "$kit/config.seed" "$kit/artifacts/config.requested"
python3 "$kit/scripts/check_config.py" "$kit/config.seed" .config
cp feeds.conf.default "$kit/artifacts/feeds.lock"
./scripts/diffconfig.sh > "$kit/artifacts/config.diff"
git diff > "$kit/artifacts/source-changes.diff"
git rev-parse HEAD > "$kit/artifacts/openwrt.commit"
git -C package/openclash-source rev-parse HEAD > "$kit/artifacts/openclash.commit"
git -C package/openclash-source diff > "$kit/artifacts/openclash-build-fix.diff"
make -j2 download
make -j2 V=s
image=bin/targets/mediatek/filogic/openwrt-25.12.5-mediatek-filogic-cudy_tr3600-v1-squashfs-sysupgrade.bin
test -f "$image"
staging_dir/host/bin/fwtool -i "$kit/artifacts/image-metadata.json" "$image"
python3 "$kit/scripts/check_image.py" "$image" "$kit/artifacts/image-metadata.json" | tee "$kit/artifacts/image-check.txt"
python3 "$kit/scripts/check_rootfs.py" "$image" "$unsquashfs" "$lan_ip" | tee "$kit/artifacts/rootfs-check.txt"
cp "$image" "$kit/artifacts/openwrt-25.12.5-mediatek-filogic-cudy_tr3600-v1-lan${lan_ip}-20261031-squashfs-sysupgrade.bin"
cp bin/targets/mediatek/filogic/*.manifest "$kit/artifacts/"
cp bin/targets/mediatek/filogic/profiles.json "$kit/artifacts/"
cp "$kit/scripts/install-mihomo.sh" "$kit/artifacts/"
cp "$kit/README.md" "$kit/artifacts/"
# Ship Mihomo separately to keep both firmware slots within the size budget.
curl --fail --location --retry 3 \
  https://github.com/MetaCubeX/mihomo/releases/download/v1.19.32/mihomo-linux-arm64-v1.19.32.gz \
  -o "$kit/artifacts/mihomo-linux-arm64-v1.19.32.gz"
echo '9dd862e28b46ff7d775f169cceebc28deccaa0a9e804237d421cd2571e0caba0  mihomo-linux-arm64-v1.19.32.gz' |
  (cd "$kit/artifacts" && sha256sum -c -)
printf '%s\n' "CANDIDATE: LAN $lan_ip; Cloudflared+LuCI installed; OpenClash+separate verified Mihomo core. Build/metadata checks only; device acceptance pending." > "$kit/artifacts/STATUS.txt"
(cd "$kit/artifacts" && sha256sum *.bin *.gz > SHA256SUMS)
