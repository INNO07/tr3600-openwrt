# Cudy TR3600 V1 双管理地址定制候选（2026-10-30）

**状态：编译工程，尚未经过设备实测。绿色 Actions 只代表编译和自动检查通过，不能称为稳定版。**

## 功能

- OpenWrt 25.12.5 固定发布提交及发布版锁定的软件源。
- 同源编译两种默认管理地址：**192.168.1.1/24** 和 **192.168.10.1/24**；每个镜像只设置其中一个，软件包和硬件补丁一致。
- 中文 LuCI、SSH、网页终端、OpenClash 0.48.002、cloudflared。
- 新增 **luci-app-cloudflared** 和简体中文翻译，菜单位于 **VPN → Cloudflared**（以构建中的菜单定义为准）。
- Mihomo v1.19.32 ARM64 单独附件及校验安装脚本，安装到共享数据卷，避免放大两个系统槽。
- 奇游预留 curl、kmod-tun、ip-full；按照奇游官方教程后装、绑定，未验证与当前系统的兼容。
- MT7990 双频无线、双 2.5G 网口、USB3、PWM 风扇、白/红 LED 的设备支持。
- 使用 Cudy 官方可配置 rootfs_volume / boot_param 内核补丁。新增升级集成只写下一槽，回读匹配后才提交启动槽。

## 编译

上传到仓库的新工作流为 `.github/workflows/build-dual-ip.yml`，进入 Actions → TR3600 dual-IP build → Run workflow。原有编译工作流保留。
工作流不会连接或刷写路由器，不会自动发布 Release。首次编译可能耗时数小时；失败应检查 build.log。
产物包含 sysupgrade.bin、完整配置、软件包清单、源代码改动、元数据、SHA256SUMS、Mihomo 内核。

OpenWrt 基础提交：`f0a60eee2fe051741c643ea6118718aae1ef17fb`（v25.12.5）。
设备移植：`046aec0dccd90f5a156cb8e9725c121c81955dd3`。
硬件补丁来源：hyqhyq3/openwrt-cudy-tr3600 `a9aa917c3a3fe3a2fb88572b77aea4f48a635549`。
OpenClash：`e553e82e01c697aefbe1555261a503f425e00ccd`。
构建时补充 `luci-base/host` 依赖，确保翻译工具 po2lmo 在并行编译前就绪；改动随产物保存。

## 升级行为与限制

升级前检查 boot_param、启动环境、实际挂载卷、镜像结构及空间。
使用标准 NAND 升级工具创建下一槽的 kernel/rootfs；**共享 rootfs_data 会重建**，保留配置时由标准 sysupgrade 备份恢复。
重建数据卷维持原有 LEB 分配，避免旧 rootfs_data_max 误缩容。裸 UBI、厂商签名包或不符尺寸的镜像会拒绝。
kernel 上限 6 MiB，root 上限 32 MiB；这个预算针对原厂双槽布局，实际容量检查仍必须通过。
已运行槽的 kernel/rootfs 不重写，但两槽共享配置，所以回退并不保留独立旧配置。
环境存储为单份 CRC 记录，掉电风险仍存在；不能承诺断电事务安全。
初次从中间固件安装使用的是中间固件自身升级脚本，本工程的升级保护只有启动本工程后才生效。

## 安装前

先检查 Actions 日志、包清单和镜像 SHA256。然后 Mac 有线连 LAN，按 Cudy 官方步骤在原厂网页上传官方中间固件。
中间固件启动后先采集板型、启动参数、环境、卷大小，并运行 `sysupgrade -T` 检查最终镜像。
确认该阶段会写哪个槽以及启动哪个槽后，再提供对应安装命令。**此 README 不提供绕过检查的强刷命令。**
不要恢复旧 Crostia/OpenWrt 无线或防火墙配置，不使用 ubootmod 镜像，不覆盖 BL2/Factory/bdinfo/FIP。

## 首次配置

LAN 默认地址以所选变体为准，镜像文件名包含完整地址；首启先设置管理员密码。
Wi-Fi 默认关闭：进入 网络 → 无线，分别为 2.4G/5G 设置地区、SSID 和密码并启用。
地区默认 CN，可在 LuCI 更改；功率可手动调节，实际有效范围受法规、驱动及校准数据约束。
初测建议 2.4G 20 MHz、5G 非 DFS 信道 36 / 80 MHz，先确认网页开关、连接和重启保持正常，再调节。
不写入过时的 ieee80211v/bss_transition 选项。Wi-Fi 7/MLO/160 MHz 暂不作为验收前提，也不保证原厂全部无线特性可用。
OpenClash 默认关闭，先校验安装同批 Mihomo 内核，再导入订阅并启动；启用前联网校时。
cloudflared 需要在 Cloudflare 控制台创建 Tunnel，再在本机配置凭据，不把 token 放入公开仓库。
奇游最后后装。游戏设备在 OpenClash 中设直连仅是分流方案，仍需验证 DNS、UDP 和策略路由不会冲突。
网页终端绑定 LAN，终端使用 /bin/login 验证管理员密码，不添加 WAN 管理入口。

## 必须完成的验收

1. 插件关闭：两网口协商、实际吞吐、双频分别启停/连接/持续传输、网页操作和重启配置保存。
2. 温度变化时风扇档位、供电与 LED 行为；待机风扇停转不等于故障。
3. OpenClash：Mihomo 能执行、配置检查通过、DNS/UDP/直连/代理、重启自启。
4. cloudflared：直连建立 Tunnel、长时间连接与重连；奇游绑定及游戏实际加速。
5. 三服务同时运行时观察内存、温度、DNS 与规则冲突，连续运行至少 24 小时。
6. 双槽功能需实际完成一次后续升级并确认 kernel/rootfs 成对匹配；模拟测试不算实机双槽验证。

`tr3600-audit` 可输出不包含订阅、密码和 token 的报告。端口协商/吞吐、游戏体验等仍需现场验证。
没有验收结果之前，只能称为候选固件。

## 本地检查记录（2026-10-16）

- 两个移植补丁应用到 25.12.5 成功；prepare.py 对固定源码执行成功。
- 官方 999 内核补丁在 Linux 6.12.94 的 block.c、kernel/Makefile（先应用 491/493）上应用成功。
- 7 组脚本模拟测试通过，覆盖双向槽切换、RAM 接管、槽/卷错误、CRC/空间失败、写入/回读/数据卷分配/配置恢复失败，以及环境提交失败。
- Shell/Python 语法、工作流 YAML 解析通过。Linux 配置检查曾暴露中文翻译和版本命名的前置开关缺失，现已补齐。
- 使用固定源码自带的 Kconfig 解析器复现这三项被取消，并验证补齐 IMAGEOPT、LUCI_LANG_zh_Hans 后三项均保留。这是针对该问题的回归检查，完整 Linux 配置和编译仍需 Actions 验证。
- 固定 fstools 版本查到挂载共享 rootfs_data 的逻辑；固定 ttyd 配置使用 /bin/login；cloudflared 包版本为 2026.3.0。
- 奇游官方 qyplug.sh 静态检查包含 aarch64 分支，未执行脚本；闭源客户端、防火墙及 OpenClash 共存仍未验证。

## 来源与许可

- https://github.com/openwrt/openwrt （OpenWrt GPL-2.0 等项目许可）
- https://github.com/openwrt/openwrt/pull/24596 （设备 DTS GPL-2.0-or-later OR MIT）
- https://github.com/hyqhyq3/openwrt-cudy-tr3600 （DTS 修正，沿用设备源码许可）
- https://www.cudy.com/zh-cn/pages/download-center/tr3600-1-0 （官方开发包 / Dual Image Note）
- https://github.com/vernesong/OpenClash （MIT）
- https://github.com/MetaCubeX/mihomo （GPL-3.0）
- https://www.qiyou.cn/games/218703.html （奇游官方安装流程）

本工程新增脚本按 GPL-2.0-or-later 发布；第三方代码和二进制沿用各自许可证。

## 本版本的配置与升级约束

- 延续此前成功构建的固定 OpenWrt、设备移植、硬件补丁和 OpenClash 提交，新增 Tunnel 的中文 LuCI 页面及 对应管理地址的首启设置；没有引入曾不兼容的第三方风扇插件，也没有替换信道分析页面。
- 本版本不预置 root/Wi-Fi 密码、订阅、Tunnel Token 或个人备份。cloudflared 程序和管理界面已安装，实际连接仍需创建自己的 Tunnel 并填写 Token。
- OpenClash 界面和依赖已编入；**Mihomo 核心仍作为同批附件安装**，不谎称镜像里已有核心。原因是旧双槽 rootfs 上限为 32 MiB，内嵌约 20 MiB 的压缩核心可能超出布局预算。已在同批附件提供校验安装脚本。
- 希望以 192.168.10.1 和新版默认配置开始时，应在正式升级检查通过后按交付说明使用干净配置。恢复旧备份会恢复备份中的网络地址和其他设置，不要把旧备份直接当成新版首启配置。
- 从已安装本工程的 OpenWrt 升级通常无需重走中间固件；从 Cudy 原厂或其他定制系统进入仍需单独核对当前环境，不能仅凭这个 README 强刷。
- **保留 6 MiB kernel / 32 MiB root 的尺寸、板型、双槽、回读和数据卷检查。** 检查失败必须修复，不能加 force 绕过。
- 产物加入 完整管理地址和日期标识；自动检查通过后仍需在设备上验收双频无线、网口、内核风扇、OpenClash 和 Tunnel。

## 两版本编译

工作流矩阵传入 192.168.1.1 和 192.168.10.1，调用 scripts/configure_variant.py，在编译前同时更新 firstboot、failsafe 配置和版本记录。测试及真实 SquashFS 检查必须与当前矩阵地址一致。两个固件不能用复制文件、改文件名的方式冒充。

## Build repair 2026-10-31

The prior successful base, hardware patches and upgrade guard remain fixed. The failed dual-IP run exposed two build integration errors: PREINITOPT was missing, which discarded the LAN10 failsafe IP; and the new rootfs audit referenced a host unsquashfs binary which OpenWrt does not build. This revision enables PREINITOPT, sets the matching netmask/broadcast and board LAN default, installs Ubuntu squashfs-tools, checks the executable before cloning/building, and still verifies the actual SquashFS. No checks are bypassed.
